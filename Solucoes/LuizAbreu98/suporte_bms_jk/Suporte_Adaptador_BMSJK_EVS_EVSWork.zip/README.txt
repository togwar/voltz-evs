Suporte / Guia Adaptador BMS JK (JK-BD6A24S-8P) para Bateria Voltz EVS / EVS Work by LuizAbreu98 on Thingiverse: https://www.thingiverse.com/thing:7369986

Summary:
Este é um guia adaptador projetado para fixar a placa BMS JK-BD6A24S-8P perfeitamente dentro da carcaça original da bateria das motos Voltz EVS e EVS Work. A peça permite o uso das furações originais da caixa da bateria, garantindo uma instalação limpa, segura e sem a necessidade de fazer novos furos, usar cola ou deixar a placa solta.